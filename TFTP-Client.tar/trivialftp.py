'''
File acts as a Trivial File Transfer Protocol Client using UDP.  Does basic read and write operations and handels errors
'''

import argparse
import socket
import time
from constructpacket import build_rrq
from constructpacket import build_wrq
from constructpacket import build_data
from constructpacket import build_ack
from constructpacket import build_error

from deconstructpacket import unpack_data
from deconstructpacket import unpack_ack
from deconstructpacket import unpack_error

'''
ARGPARSE

FORMAT:
    1.	‘-a’ is for IP Addresses,
    2.	‘-sp’ for server port
    3.	‘-f’ for file name,
    4.	‘-p’ for port numbers
    5.	‘-m’ for mode (r = read from server, w = write to server)

Example: python3 trivialftp.py -a 234.45.345.2 -sp 50001 -p 50000 -f mytext.txt -m w
'''
parser = argparse.ArgumentParser(description='Communicate Via TFTP')
parser.add_argument('-a', '--address', help='IP Address', required=True)
parser.add_argument('-sp', '--serverport', type=int, help='Server Port', required=True)
parser.add_argument('-p', '--clientport', type=int, help='Port Number', required=True)
parser.add_argument('-f', '--filename', type=str, help='File Name', required=True)
parser.add_argument('-m', '--mode', type=str, help='Mode: r = read from server, w = write to server', required=True)
args = parser.parse_args()
if (args.mode != 'r' and args.mode != 'w'):
    print("Invalid mode: Must use 'r' for Read or 'w' for Write")
    exit()
elif (args.serverport < 5000 or args.serverport > 65535 or args.clientport < 5000 or args.clientport > 65535):
    print("Port numbers must be between 5000 and 65,535")
    exit()

clientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
clientSocket.settimeout(1)
# CHECK FOR CORRECT TID
def check_tid(message, serverAddress):
    # DO WHILE ADDRESSES DON'T MATCH (E.G. YOU PICKED UP A RANDOM PACKET)
    while serverAddress != (args.address, args.serverport):
        # SEND ERROR MESSAGE TO WRONG IP
        packetERROR = build_error(5, 'Unknown transfer ID')
        clientSocket.sendto(packetERROR, serverAddress)
        # RECEIVE CORRECT PACKAGE
        message, serverAddress = clientSocket.recvfrom(2048)
    # CHECKS IF PACKET IS ERROR PACKET -> CLOSES SOCKET
    if message[1] == 5:
        clientSocket.close()
    return message

# FUNCTION TO SEND A PACKET THAT HAS AN EXPECTED RESPONSE (RRQ, WRQ, DATA, or ACK)
def send_receive_packet(packet):
    # SEND PACKET
    clientSocket.sendto(packet, (args.address, args.serverport))
    # LISTEN FOR A RESPONSE
    message, serverAddress = clientSocket.recvfrom(2048)
    # CHECK FOR TID MATCH AND ERROR PACKET
    message = check_tid(message, serverAddress)
    # WHILE( PACKET IS EITHER A DATA OR ACK PACKET ) && (THE BLOCK NUMBERS FROM SENT AND RECEIVED PACKETS DO NOT MATCH)
    # BASICALLY CHECKS FOR DROPPED PACKETS AND RESENDS
    while (packet[1] == 3 and (message[2], message[3]) != (packet[2], packet[3])) \
       or (packet[1] == 4 and (int.from_bytes((message[2], message[3]), "big") != int.from_bytes((packet[2], packet[3]), "big") + 1)):
        # IF BLOCK NUMBER = 65535, START AT BLOCK NUMBER = 0
        if int.from_bytes((packet[2], packet[3]), "big") == 65535 and int.from_bytes((message[2], message[3]), "big") == 0:
            return (message)
        # RESEND LOST PACKET
        clientSocket.sendto(packet, (args.address, args.serverport))
        # LISTEN FOR A RESPONSE
        message, serverAddress = clientSocket.recvfrom(2048)
        # CHECK FOR TID MATCH AND ERROR PACKET
        message = check_tid(message, serverAddress)
    return(message)


if __name__ == '__main__':
    # IF MODE = READ
    if args.mode == 'r':
        # BUILD READ-REQUEST PACKET
        packetRRQ = build_rrq(args.filename, 'netascii')
        time.sleep(1)
        # SEND RRQ PACKET
        message = send_receive_packet(packetRRQ)
        # CHECK IF MESSAGE IS DATA PACKET
        if message[1] == 3:
            # UNPACK DATA PACKET
            (opcode, blockNum, data) = unpack_data(args.filename, message)
            # BUILD ACK PACKET
            packetACK = build_ack(blockNum)
            # IF DATA == 512, SEND ACK AND RECEIVE....
            if len(data) == 512:
                while len(data) > 511:
                    # SEND ACK, RECEIVE DATA
                    message = send_receive_packet(packetACK)
                    # UNPACK DATA PACKET
                    (opcode, blockNum, data) = unpack_data(args.filename, message)
                    # BUILD ACK PACKET
                    packetACK = build_ack(blockNum)

            # IF DATA < 512, SEND ACK AND SHUTDOWN CONNECTION
            # SEND FINAL ACK
            clientSocket.sendto(packetACK, (args.address, args.serverport))
    # IF MODE = WRITE
    elif args.mode == 'w':
        # BUILD WRITE-REQUEST PACKET
        packetWRQ = build_wrq(args.filename, 'netascii')
        time.sleep(1)
        # SEND WRQ PACKET
        message = send_receive_packet(packetWRQ)
        # CHECK IF PACKET IS ACK PACKET
        if message[1] == 4:
            # UNPACK ACK PACKET
            blockNum = unpack_ack(message)
            # INITIALIZE DATA LENGTH = 512
            dataLen = 512
            with open(args.filename, "r") as file_object:
                while dataLen == 512:
                    # INCREASE BLOCK NUMBER BY 1 (STARTING AT 1)
                    blockNum = blockNum + 1
                    # COLLECT UP TO 512 BYTES OF DATA FROM FILE
                    data = file_object.read(512)
                    # RECORD DATA LENGTH
                    dataLen = len(data)
                    # CONVERT TO BYTE ARRAY
                    data = bytearray(data.encode('utf-8'))
                    # CONSTRUCT DATA PACKET
                    packetDATA = build_data(data, blockNum)
                    # SEND DATA PACKET
                    message = send_receive_packet(packetDATA)
                    # UNPACK ACK PACKET
                    blockNum = unpack_ack(message)
# CLOSE THE SOCKET
clientSocket.close()




